package main

import (
	"fmt"
	"net"
	"encoding/gob"
	"strconv"
)
/*
type P struct {
	M, N int64
}*/


type V struct {
	A string
}


func handleConnection(conn net.Conn) {
	encoder := gob.NewEncoder(conn)
	decoder := gob.NewDecoder(conn)
	//p := &P{}
	data := []V{}
	decoder.Decode(&data)
	fmt.Printf("Received: ")
	fmt.Println(data)

	if len(data) == 0 {
		fmt.Printf("Data is empty. Aborting...\n")
		return
	}

	var sum int
	var avg float64
	numbersCount := len(data)

	for i := 0; i < len(data); i++ {
		if num, err := strconv.Atoi(data[i].A); err != nil {
			fmt.Printf("%q doesn't look like a number. I'm dropping it.\n", data[i].A)
			numbersCount = numbersCount - 1
		} else {
			sum += num
		}

	}

	avg = float64(sum) / float64(numbersCount)

	fmt.Printf("Average: ")
	fmt.Println(avg)
	encoder.Encode(avg)


	conn.Close()
}

func main() {
	fmt.Println("start");
	ln, err := net.Listen("tcp", ":8080")

	if err != nil {
		// handle error
	}

	for {
		conn, err := ln.Accept() // this blocks until connection or error
		if err != nil {
			// handle error
			continue
		}
		go handleConnection(conn) // a goroutine handles conn so that the loop can accept other connections
	}
}