package main

import (
	"fmt"
	"log"
	"net"
	"encoding/gob"
)

type V struct {
	A string
}


func main() {
	fmt.Println("start client");
	conn, err := net.Dial("tcp", "localhost:8080")
	if err != nil {
		log.Fatal("Connection error", err)
	}
	//data := vector{}

	encoder := gob.NewEncoder(conn)
	decoder := gob.NewDecoder(conn)

	data := []V{}

	var temp int
	var num string
	fmt.Print("Enter number of elements: ")
	fmt.Scanln(&temp)
	for i := 0; i < temp; i++ {
		fmt.Print("Enter the number : ")
		fmt.Scanln(&num)

		/*_, err := strconv.ParseInt(num, 10, 0)

		if err != nil {
			fmt.Println("Parameter must be integer")
			os.Exit(1)
		}*/

		data = append(data, V{num})
	}
	fmt.Println("Sending")
	fmt.Println(data)
	//p := &P{1, 2}
	encoder.Encode(data)


	fmt.Println("Waiting for answer");
	var response float64
	decoder.Decode(&response)
	fmt.Println("Received: ", response)

	conn.Close()


}