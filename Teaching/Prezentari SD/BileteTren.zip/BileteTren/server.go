package main

import (
	"fmt"
	"net"
	"encoding/gob"
	"strconv"
	"bytes"
)
/*
type P struct {
	M, N int64
}*/


func handleConnection(conn net.Conn, luckyNumbers []int, freqArray []int) {

	for {

		codes := make(map[int]string)
		codes[0] = "Success!"
		codes[1] = "Number already chosen! Choose another one!"
		codes[2] = "The number is not available!"

		encoder := gob.NewEncoder(conn)
		decoder := gob.NewDecoder(conn)
		//p := &P{}

		var buffer bytes.Buffer
		for i := 0; i < len(freqArray); i++ {
			if freqArray[i] < 1 {
				buffer.WriteString(strconv.Itoa(luckyNumbers[i]) + " ")
			}
		}
		encoder.Encode(buffer.String())

		var data string
		decoder.Decode(&data)

		if data == "stop" {
			break
		}

		fmt.Printf("Received: ")
		fmt.Println(data)

		if number, err := strconv.Atoi(data); err != nil {
			fmt.Printf("%q is not a number .\n", data)
			return
		} else {

			ok := false
			for i := 0; i < len(luckyNumbers); i++ {
				if number == luckyNumbers[i] {
					ok = true
				}
			}
			if ok == false {
				encoder.Encode(2)
				return
			}

			if freqArray[number-1] < 1 {
				freqArray[number-1]++
				encoder.Encode(0)
			} else {
				encoder.Encode(1)
			}

		}

	}

	conn.Close()
}

func main() {
	luckyNumbers := []int{1,2,3,4,5,6,7,8,9,10}
	freqArray := []int{0,0,0,0,0,0,0,0,0,0}

	fmt.Println("start");
	ln, err := net.Listen("tcp", ":8080")
	if err != nil {
		// handle error
	}
	for {
		conn, err := ln.Accept() // this blocks until connection or error
		if err != nil {
			// handle error
			continue
		}
		go handleConnection(conn, luckyNumbers, freqArray) // a goroutine handles conn so that the loop can accept other connections
	}
}