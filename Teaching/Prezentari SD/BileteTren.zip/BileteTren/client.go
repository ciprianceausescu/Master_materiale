package main

import (
	"fmt"
	"log"
	"net"
	"encoding/gob"
)


func main() {

	conn, err := net.Dial("tcp", "localhost:8080")
	if err != nil {
		log.Fatal("Connection error", err)
	}


	fmt.Println("\n\nYou can buy multiple tickets. Write 'stop' to exit! ")

	for {

		codes := make(map[int]string)
		codes[0] = "Success!"
		codes[1] = "Number already chosen! Choose another one!"
		codes[2] = "The number is not available!"

		encoder := gob.NewEncoder(conn)
		decoder := gob.NewDecoder(conn)

		var receivedData string
		var data string

		decoder.Decode(&receivedData)
		fmt.Print("Available tickets: \n")
		fmt.Print(receivedData)
		fmt.Print("\nWhat ticket do you want? ")

		fmt.Scanln(&data)

		if data == "stop" {
			return
		}

		/*fmt.Print("Sending ")
	fmt.Println(data)*/

		encoder.Encode(data)

		var response int
		decoder.Decode(&response)
		fmt.Println(codes[response])

	}

	conn.Close()
}