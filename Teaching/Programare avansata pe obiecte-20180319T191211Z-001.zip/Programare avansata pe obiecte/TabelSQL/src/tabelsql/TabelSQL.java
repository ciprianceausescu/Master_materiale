/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tabelsql;

/**
 *
 * @author Marina
 */


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.*;

public class TabelSQL extends JFrame 
{
static  private Connection link;
	private Statement statement;
	private ResultSet results;
	private JTable table;
	private JScrollPane scroller;
	private final String[] heading =
		{"Nume: " ,"Prenume:  " , "Telefon Mobil: ", "Telefon Fix: ", "Email: " , "Adresa: " , "Oras: " , "Judet: ", "Cod Postal: " };
	private Vector<String> heads;
	private Vector<Object> row;
	private Vector<Vector<Object>> rows;

	public static void main(String[] args)
	{
		TabelSQL frame = new TabelSQL();
		frame.setSize(400,200);
		frame.setVisible(true);

		frame.addWindowListener(
			new WindowAdapter()
			{
				public void windowClosing(WindowEvent winEvent)
				{
					try
					{
						link.close();
						System.exit(0);
					}
					catch(SQLException sqlEx)
					{
						System.out.println(
							"* Error on closing connection! *");
					}
				}
			}
		);
    
 }
        
public TabelSQL()
{
		setTitle("Contacte Agenda");
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			link = DriverManager.getConnection("jdbc:mysql://localhost:3306/contacte", "root", "1234");
			statement = link.createStatement();
			results = statement.executeQuery("SELECT * FROM agenda");

			heads = new Vector<String>();
			for (int i=0; i<heading.length; i++)
			{
				heads.add(heading[i]);
			}

			rows = new Vector<Vector<Object>>();

			while (results.next())
			{
				row = new Vector<Object>();//Heterogeneous collection.
				row.add(results.getString(1));
				row.add(results.getString(2));
				row.add(results.getString(3));
				row.add(results.getString(4));
                                row.add(results.getString(5));
                                row.add(results.getString(6));
                                row.add(results.getString(7));
                                row.add(results.getString(8));
                                row.add(results.getString(9));
				rows.add(row);
			}
			table = new JTable(rows,heads);
			scroller = new JScrollPane(table);
			add(scroller, BorderLayout.CENTER);
		}
		catch(ClassNotFoundException cnfEx)
		{
			System.out.println("* Nu am putut incarca driverul! *");
			System.exit(1);
		}
		catch(SQLException sqlEx)
		{
			System.out.println("* Eroare SQL! *");
			System.exit(1);
		}
   }
}
