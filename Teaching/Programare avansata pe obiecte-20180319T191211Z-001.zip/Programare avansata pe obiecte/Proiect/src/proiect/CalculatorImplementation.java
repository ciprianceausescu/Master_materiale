import java.rmi.*;
import java.rmi.server.*;
import java.io.*;
import java.util.*;

public class CalculatorImplementation extends UnicastRemoteObject
implements ICalculator {
	
public static double [] valori = new double [100];

public static double [] memorie = new double [100];

public static boolean [] stare = new boolean[100];

public static int [] coduri_eroare = new int[100]; // CODURI de eroare prestabilite: 1 = Impartirea la 0 nu este posibila.
    
public static int ID = -1; // ID va fi ID-ul calculatorului curent
        
	
		
    public CalculatorImplementation() throws RemoteException, IOException 
	{
		for(int i=0; i<100; i++)
		{
			valori[i] = 0;
                        memorie[i] = 0; 
                        coduri_eroare[i] = 0;
			stare[i] = true;
		}
        }
    
	
    
        @Override 
	public int Pornire_calculator() throws RemoteException
	{
		ID = ID + 1;
		return ID;
	}
        
        
        @Override 
	public boolean StareCurenta (int id) throws RemoteException
	{
		return stare[id];
	}
	
        @Override 
	public int CodEroare (int id) throws RemoteException
	{
		return coduri_eroare[id];
	}
	
        @Override 
	public double ValActuala (int id) throws RemoteException
	{
		return valori[id];
	}
	
        @Override 
	public double Memorie (int id) throws RemoteException
	{
		return memorie[id];
	}
	
      
        @Override 
	public void AdaugaValoare(int id, double a) throws RemoteException
	{    
		valori[id] = valori[id] + a;
		stare[id] = true; 
                coduri_eroare[id] = 0;
	}
       
        @Override 
	public void Adunare (int id, double a) throws RemoteException
	{
		valori[id] = valori[id] + a;
		stare[id] = true; 
                coduri_eroare[id] = 0;
	}
        
        
        
	@Override 
	public void Scadere (int id, double a) throws RemoteException
	{
		valori[id] = valori[id] - a;
		stare[id] = true; 
                coduri_eroare[id] = 0;
	}
	
        
      @Override 
	public void Inmultire(int id, double a) throws RemoteException
	{
		valori[id] = valori[id] * a;
		stare[id] = true; 
                coduri_eroare[id] = 0;
	}
	
       @Override 
	public void Impartire (int id, double a) throws RemoteException
	{
		if(a == 0.0)
		{
			stare[id] = false; 
                        coduri_eroare[id] = 1;
			return;
		}
                
		valori[id] = valori[id] / a;
		stare[id] = true; 
                coduri_eroare[id] = 0;
	}
	
        
        @Override 
	public void Inversare (int id) throws RemoteException
	{
		
		double invers = 0; int x;
                x = (int)valori[id] ;
                
		while( x > 0)
		{
			invers = invers * 10 + x % 10;
			x = x / 10;
		}
		
                valori[id] = invers;
		stare[id] = true; 
                coduri_eroare[id] = 0;
	}
	
        @Override 
	public void Putere (int id, double a) throws RemoteException
	{       
            int p = (int) a;
		if(p == 0)
		{
			valori[id] = 1;
                        stare[id] = true; 
                        coduri_eroare[id] = 0;
                        
			return;
		}
		
                if(p < 0)
		{       
                        valori[id] = 1 / valori[id];
			stare[id] = true; 
                        coduri_eroare[id] = 0;
			return;
		}
                
		double v = valori[id];
                
		while(p > 1)
		{
			p--;
			valori[id] = valori[id] * v;
		}
		
                stare[id] = true; 
                coduri_eroare[id] = 0;
		
	}
        
      
	@Override 
	public void Factorial (int id) throws RemoteException
	{
		int convertit = (int)valori[id];
		int fact = 1;
                
		for(int i = 1; i<= convertit; i++)
			fact = fact * i;
                
		valori[id] = (double) fact;
		stare[id] = true; 
                coduri_eroare[id] = 0;
	}
	
        @Override 
	public void RadacinaPatrata (int id) throws RemoteException
	{
		valori[id] = Math.sqrt(valori[id]);
		stare[id] = true; 
                coduri_eroare[id] = 0;
	}
        
       
	@Override 
	public void AdunaInMemorie (int id) throws RemoteException
	{
		memorie[id] = memorie[id] + valori[id];
		stare[id] = true; 
                coduri_eroare[id] = 0;
	}
        
       
	@Override 
	public void ScadeDinMemorie (int id) throws RemoteException
	{
		memorie[id] = memorie[id] - valori[id];
		stare[id] = true; 
                coduri_eroare[id] = 0;
	}
        
        
	@Override 
	public void StocareInMemorie (int id) throws RemoteException
	{
		memorie[id] = valori[id];
		stare[id] = true;
                coduri_eroare[id] = 0;
	}
	
        
        @Override 
	public void CitireMemorie (int id) throws RemoteException
	{
		valori[id] = memorie[id];
		stare[id] = true; 
                coduri_eroare[id] = 0;
	}
	
        
        @Override 
	public void StergereMemorie (int id) throws RemoteException
	{
		memorie[id] = 0;
		stare[id] = true;
                coduri_eroare[id] = 0;
	}

}
