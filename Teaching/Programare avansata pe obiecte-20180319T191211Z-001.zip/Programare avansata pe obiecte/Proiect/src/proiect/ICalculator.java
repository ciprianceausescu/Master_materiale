import java.rmi.*;

public interface ICalculator extends Remote
{
       
       public int Pornire_calculator()  throws RemoteException; // intoarce ID-ul asociat calculatorului nou creat.
    
    
        // Verificare
	
        public boolean StareCurenta(int id) throws RemoteException;
	
        public int CodEroare(int id) throws RemoteException;
	
        public double ValActuala(int id) throws RemoteException;
	
        public double Memorie(int id) throws RemoteException;



       // Operatii de baza
        
        public void Adunare (int id, double a) throws RemoteException; //op. 1 
	
        public void Scadere (int id, double a) throws RemoteException; //op. 2
	
        public void Inmultire (int id, double a) throws RemoteException; //op. 3
	
        public void Impartire  (int id, double a) throws RemoteException; //op. 4
	

        // Operatii extinse
	public void Inversare (int id) throws RemoteException; //op. 5
     
	public void Putere (int id, double a) throws RemoteException; //op. 6
      
	public void Factorial (int id) throws RemoteException; //op. 7
       
	public void RadacinaPatrata (int id) throws RemoteException; //op. 8
        
        
	// Operatii folosind memoria
        public void AdunaInMemorie (int id) throws RemoteException; //op. 9
	
        public void ScadeDinMemorie (int id) throws RemoteException; //op. 10
      
	public void StocareInMemorie (int id) throws RemoteException; //op. 11
        
        public void CitireMemorie (int id) throws RemoteException; //op. 12
       
	public void StergereMemorie (int id) throws RemoteException; //op. 13	 
        
        public void AdaugaValoare (int id, double a) throws RemoteException;  //op. 14
	
    }