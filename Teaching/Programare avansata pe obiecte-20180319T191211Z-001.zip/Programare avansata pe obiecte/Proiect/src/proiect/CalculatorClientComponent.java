import java.rmi.*;
import java.util.*;

public class CalculatorClientComponent 
{
        private static final String host = "localhost";
	private static int nrCalculator = 0;
	
        public static void arata (double valoare, double memorie)
	{
		System.out.print("\n");
		System.out.println("         Valoare curenta: " + valoare + "    Memorie: " + memorie + "\n" );
	}
	
        public static void Delimitare()
	{   
            for(int i=0; i<80; i++) 
               System.out.print("*");
            
	    System.out.print("\n");
		
	}
	 
        private static void ApasareTastaCont()
       {    
           System.out.println("Pentru a continua, apasiati orice tasta:  ");
          
           try
          {
             System.in.read(); // apasam enter ca sa treaca mai departe
          }  
            catch(Exception e)
            { }  
       }
        
        
        
    public static void main(String[] args) 
    {
        try 
        {   
            int alegere = 1;
                        
	    double numar; 
                        
            Scanner sc = new Scanner(System.in);
            
            //We obtain a reference to the object from the registry and next,
            //it will be typecasted into the most appropriate type.
            
            ICalculator ob = (ICalculator) Naming.lookup("rmi://"  + host + "/Calculator");
            
            nrCalculator = ob.Pornire_calculator(); // Pornim calculatorul, crestem ID-ul cu 1
			
                while(alegere != 0)
	       {        
                    System.out.print("\n\n\n");
                            
                    System.out.println("***********************************  CALCULATOR  ******************************* ");
                                
                    arata(ob.ValActuala(nrCalculator) , ob.Memorie(nrCalculator));
                                
                    Delimitare();
                                
                    System.out.println("    Operatii: ");
                    System.out.print("\n");
		    System.out.println("    1. Adunare ");
                    System.out.println("    2. Scadere ");
                    System.out.println("    3. Inmultire ");
                    System.out.println("    4. Impartire ");
                    System.out.println("    5. Inversare ");
                    System.out.println("    6. Ridicare la putere ");
                    System.out.println("    7. Factorial ");
                    System.out.println("    8. Radical ");
                            
                    System.out.print("\n\n");
                            
                    System.out.println("    Operatii cu memoria: ");
                    System.out.print("\n");
                    System.out.println("    9. Adunare     (Aduna valoarea curenta la cea din memorie) ");
                    System.out.println("    10. Scadere    (Scade valoarea curenta din memorie) ");
                    System.out.println("    11. Stocare    (Stocheaza valoarea curenta in memorie) ");
                    System.out.println("    12. Citire     (Citeste valoarea din memorie si o pune ca valoare curenta) ");
                    System.out.println("    13. Stergere   (Sterge valoarea din memorie) ");
                    System.out.print("\n");
                    System.out.println("    14. Adauga valoare (Doar daca valoarea curenta este 0) ");
                    System.out.print("\n");
                    System.out.println("    0. Inchidere aplicatie.");
                    System.out.println("");
                    System.out.print("    Introduceti numarul operatiei dorite: ");
				
		    alegere = sc.nextInt();
				
                    switch(alegere)
		   {
			case 1:  
                                if ( ob.ValActuala(nrCalculator) == 0)
                                  
                                {  System.out.println("Introduceti o valoare: ");
                                                
				   numar = sc.nextDouble();
						
                                   ob.AdaugaValoare(nrCalculator, numar);
                                }
                                
                                
                                    
                                arata( ob.ValActuala(nrCalculator), ob.Memorie(nrCalculator) );
                                                
				System.out.println("Introduceti valoarea de adunat: ");
                                                
				numar = sc.nextDouble();
						
                                ob.Adunare(nrCalculator, numar);
						
                                if(ob.StareCurenta(nrCalculator)!= true)
                                                  
                                  System.out.println("Eroare. Codul erorii este: " + ob.CodEroare(nrCalculator));
						
                                ApasareTastaCont();
                             
					
                        break;
                        
					
                        
                        case 2:
			         if ( ob.ValActuala(nrCalculator) == 0)
                                  
                                {  System.out.println("Introduceti o valoare: ");
                                                
				   numar = sc.nextDouble();
						
                                   ob.AdaugaValoare(nrCalculator, numar);
                                }
                                
                            
                                arata(ob.ValActuala(nrCalculator), ob.Memorie(nrCalculator));
			        
                                System.out.println("Introduceti valoarea de scazut: ");
                                
				numar = sc.nextDouble();
                                
				ob.Scadere(nrCalculator, numar);
				
                                if(ob.StareCurenta(nrCalculator) != true)
                                    
                                 System.out.println("Eroare. Codul erorii este: " + ob.CodEroare(nrCalculator));
				
                                ApasareTastaCont();
			break;
                        
					
                        case 3:
                                 if ( ob.ValActuala(nrCalculator) == 0)
                                  
                                {  System.out.println("Introduceti o valoare: ");
                                                
				   numar = sc.nextDouble();
						
                                   ob.AdaugaValoare(nrCalculator, numar);
                                }
                                
                            
                                arata(ob.ValActuala(nrCalculator), ob.Memorie(nrCalculator));
			        
                                System.out.println("Introduceti valoarea de inmultit: ");
				
                                numar = sc.nextDouble();
				
                                ob.Inmultire(nrCalculator, numar);
                                
				if(ob.StareCurenta(nrCalculator) != true)
                                    
                                 System.out.println("Eroare. Codul erorii este: " + ob.CodEroare(nrCalculator));
				
                                 ApasareTastaCont();
                                 
			break;
                        
			
                        case 4:
				 if ( ob.ValActuala(nrCalculator) == 0)
                                  
                                {  System.out.println("Introduceti o valoare: ");
                                                
				   numar = sc.nextDouble();
						
                                   ob.AdaugaValoare(nrCalculator, numar);
                                }
                                
                            
                                arata(ob.ValActuala(nrCalculator), ob.Memorie(nrCalculator));
                                
				System.out.println("Introduceti valoarea la care doriti sa impartiti: ");
                                
				numar = sc.nextDouble();
                                
				ob.Impartire(nrCalculator, numar);
				
                                if(ob.StareCurenta(nrCalculator)!= true)
			           
                                  System.out.println("Eroare. Codul erorii este: " + ob.CodEroare(nrCalculator));
			       
                                ApasareTastaCont();
                                
			break;
                        
					
                        
                        case 5:
				 if ( ob.ValActuala(nrCalculator) == 0)
                                  
                                {  System.out.println("Introduceti o valoare: ");
                                                
				   numar = sc.nextDouble();
						
                                   ob.AdaugaValoare(nrCalculator, numar);
                                }
                                
                            
                                arata(ob.ValActuala(nrCalculator), ob.Memorie(nrCalculator));
                                
				ob.Inversare(nrCalculator);
                                
				if(ob.StareCurenta(nrCalculator) != true)
                                
                                  System.out.println("Eroare. Codul erorii este: " + ob.CodEroare(nrCalculator));
                                
				ApasareTastaCont();
                                
			break;
                        
					
                        case 6:
				 if ( ob.ValActuala(nrCalculator) == 0)
                                  
                                {  System.out.println("Introduceti o valoare: ");
                                                
				   numar = sc.nextDouble();
						
                                   ob.AdaugaValoare(nrCalculator, numar);
                                }
                                
                            
                                arata(ob.ValActuala(nrCalculator), ob.Memorie(nrCalculator));
                                
				System.out.println("Introduceti valoarea pentru ridicare la putere: ");
                                
				numar = sc.nextInt();
                                
				ob.Putere(nrCalculator, numar);
                                
				if(ob.StareCurenta(nrCalculator) != true)
                               
                                  System.out.println("Eroare. Codul erorii este: " + ob.CodEroare(nrCalculator));
                                
				ApasareTastaCont();
                                
			break;
                        
					
                        
                        case 7:
				 if ( ob.ValActuala(nrCalculator) == 0)
                                  
                                {  System.out.println("Introduceti o valoare: ");
                                                
				   numar = sc.nextDouble();
						
                                   ob.AdaugaValoare(nrCalculator, numar);
                                }
                                
                                
                                arata(ob.ValActuala(nrCalculator), ob.Memorie(nrCalculator));
                                
				ob.Factorial(nrCalculator);
                                
				if(ob.StareCurenta(nrCalculator) != true)
				
                                  System.out.println("Eroare. Codul erorii este: " + ob.CodEroare(nrCalculator));
                                
				ApasareTastaCont();
			break;
                        
					
                        
                        case 8:
				 if ( ob.ValActuala(nrCalculator) == 0)
                                  
                                {  System.out.println("Introduceti o valoare: ");
                                                
				   numar = sc.nextDouble();
						
                                   ob.AdaugaValoare(nrCalculator, numar);
                                }
                                
                            
                                arata(ob.ValActuala(nrCalculator), ob.Memorie(nrCalculator));
                                
                                ob.RadacinaPatrata(nrCalculator);
                                
				if(ob.StareCurenta(nrCalculator) != true)
				
                                  System.out.println("Eroare. Codul erorii este: " + ob.CodEroare(nrCalculator));
                                
				ApasareTastaCont();
			break;
                        
					
                        case 9:
			       
                               arata(ob.ValActuala(nrCalculator), ob.Memorie(nrCalculator));
                               
                               
			       ob.AdunaInMemorie(nrCalculator);
                               
			          if(ob.StareCurenta(nrCalculator) != true)
				
                                  System.out.println("Eroare. Codul erorii este: " + ob.CodEroare(nrCalculator));
                                
				ApasareTastaCont();
			break;
                        
					
                        case 10:
				
                                arata(ob.ValActuala(nrCalculator), ob.Memorie(nrCalculator));
                                
				ob.ScadeDinMemorie(nrCalculator);
                                
                                  if(ob.StareCurenta(nrCalculator) != true)
				
                                  System.out.println("Eroare. Codul erorii este: " + ob.CodEroare(nrCalculator));
                                
				ApasareTastaCont();
						
			break;
                        
					
                        case 11:
				arata(ob.ValActuala(nrCalculator), ob.Memorie(nrCalculator));
                                
				ob.StocareInMemorie(nrCalculator);
                                
				  if(ob.StareCurenta(nrCalculator) != true)
				
                                   System.out.println("Eroare. Codul erorii este: " + ob.CodEroare(nrCalculator));
                                
				ApasareTastaCont();		
			break;
                        
					
                        case 12:
				arata(ob.ValActuala(nrCalculator), ob.Memorie(nrCalculator));		
						
                                ob.CitireMemorie(nrCalculator);
                                
                                  if(ob.StareCurenta(nrCalculator) != true)
				 
                                   System.out.println("Eroare. Codul erorii este: " + ob.CodEroare(nrCalculator));
                                
				ApasareTastaCont();
				   
			break;
                        
					
                        case 13:
				arata(ob.ValActuala(nrCalculator), ob.Memorie(nrCalculator));
						
                                ob.StergereMemorie(nrCalculator);
						
                                  if(ob.StareCurenta(nrCalculator) != true)
				
                                  System.out.println("Eroare. Codul erorii este: " + ob.CodEroare(nrCalculator));
                                
				ApasareTastaCont();
			break;
                        
                        
                        		
                        case 14:
				arata(ob.ValActuala(nrCalculator), ob.Memorie(nrCalculator));
						
                                 if ( ob.ValActuala(nrCalculator) == 0)
                                  
                                {  System.out.println("Introduceti o valoare: ");
                                                
				   numar = sc.nextDouble();
						
                                   ob.AdaugaValoare(nrCalculator, numar);
                                
						
                                 if(ob.StareCurenta(nrCalculator) != true)
				
                                  System.out.println("Eroare. Codul erorii este: " + ob.CodEroare(nrCalculator));
                                 
                                }
                                
				ApasareTastaCont();
			break;
                                       
				}
				
			}
				
        } 
        catch (ConnectException conEx) 
        {
            System.out.println("Unable to connect to server!");
            System.exit(1);
        } 
        catch (Exception ex) 
        {
            ex.printStackTrace();  // arata calea unde este eroarea
            System.exit(1);
        }
    }
}
