
package runnableshowname;

public class RunnableShowName 
{   

public static void main(String[] args)
   	{
    	Thread thread1 = new Thread(new RunnableShowName());
    	Thread thread2 = new Thread(new RunnableShowName());
	/*
		As an alternative to the above 2 lines, the following
		(more long-winded) code could have been used:

      	RunnableShowName runnable1 = new RunnableShowName();
      	RunnableShowName runnable2 = new RunnableShowName();

      	Thread thread1 = new Thread(runnable1);
      	Thread thread2 = new Thread(runnable2);
	*/
      	thread1.start();
      	thread2.start();
   	}
    
}
