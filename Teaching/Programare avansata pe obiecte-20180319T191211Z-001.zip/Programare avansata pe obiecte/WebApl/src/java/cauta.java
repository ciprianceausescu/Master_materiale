import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.*;
import javax.servlet.http.*;


class informatii {
 static Connection link;
 static Statement statement;
 static ResultSet results; 
 static int n=0;
 
 
 public static String[] date = new String[50];
    
    public static void sir() {
        try
  {
   Class.forName("com.mysql.jdbc.Driver");
   link = DriverManager.getConnection("jdbc:mysql://localhost:3306/contacte", "root", "1234");
  }
                catch(ClassNotFoundException cnfe)
                {
                    System.out.println(" Driverul nu a putut fi incarcat! ");
                    System.exit(1);
                }
  catch(SQLException sqlEx)
  {
   System.out.println(" Conectarea la baza de date a esuat! ");
   System.exit(1);
  }

  try
  {
   statement = (Statement) link.createStatement();
   results = statement.executeQuery("SELECT * FROM agenda");
  }
  catch(SQLException sqlEx)
  {
   System.out.println(" Interogarea nu a putut fi executata.! ");
   sqlEx.printStackTrace();
   System.exit(1);
  }
  
   
  try
  {    
      
          int i=0; 

   while (results.next())
   {  
                     date[i]=new String();
			    date[i]="<td>"+results.getString(1)+"</td><td>" +
                                           results.getString(2)+"</td><td>" +
                                           results.getString(3)+"</td><td>" +
                                           results.getString(4)+"</td><td>" +
                                           results.getString(5)+"</td><td>" +
                                           results.getString(6)+"</td><td>" +
                                           results.getString(7)+"</td><td>" +
                                           results.getString(8)+"</td><td>" +
                                           results.getString(9)+"</td>" ;
                                i++; 
       
   }
   
   n = i;
  
  } 
  catch(SQLException sqlEx)
  {
   System.out.println(" Eroare la primirea datelor! ");
   sqlEx.printStackTrace();
   System.exit(1);
  }

  try
  {
   link.close();
  }
  catch(SQLException sqlEx)
  {
   System.out.println(" Nu m-am putut deconecta! ");
   sqlEx.printStackTrace();
  }
                
 }
} 


public class cauta extends HttpServlet
{ 
 
 static Connection link;
 static Statement statement;
 static ResultSet results;
 
 
public void doGet(HttpServletRequest request,
HttpServletResponse response)
throws IOException,ServletException
{

   informatii S = new informatii();
     
   
response.setContentType("text/HTML");
PrintWriter out = response.getWriter();

out.println("<HTML>");
out.println("<HEAD>");
out.println("<TITLE>Simple Servlet</TITLE>");
out.println("</HEAD>");
out.println("<BODY>"); 


String nume = request.getParameter("Nume");
String prenume = request.getParameter("Prenume");
String adr = request.getParameter("Adresa");

S.sir(); 

String test;

out.print("<table border='1'>");
  out.println("<tr><td>Nume<td>Prenume<td>TelefonMobil<td>TelefonFix<td>Email<td>Adresa<td>Oras<td>Judet<td>CodPostal");
           int ok=0; 
            for(int i=0; i<S.n; i++)
            {   test = S.date[i];
              if(( test.contains(nume) == true) || (test.contains(prenume) == true ) || ( test.contains(adr) == true))
               { out.println("<tr>" + S.date[i] + "</tr>");
                 ok=1;
               } 
            } 
            
          if(ok==0)
            out.println("<CENTER><p> Contactul nu exsita<p></CENTER>"); 


            
out.println("</table>"); 
out.println("</BODY>");
out.println("</HTML>");
out.flush();
}
}