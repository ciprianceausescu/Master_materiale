import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

class Date
{
 static Connection link;
 static Statement statement;
 static ResultSet results; 
 static int n;
 public static String[] date = new String[50];
   
    public static void sir() 
{
    try
  {
     Class.forName("com.mysql.jdbc.Driver");
     link = DriverManager.getConnection("jdbc:mysql://localhost:3306/contacte", "root", "1234");
  }
  
    catch(ClassNotFoundException cnfe)
 {
    System.out.println(" Driverul nu a putut fi incarcat! ");
    System.exit(1);
  
 }
  catch(SQLException sqlEx)
  {
   System.out.println(" Conectarea la baza de date a esuat! ");
   System.exit(1);
  }

  try
  {
   statement = (Statement) link.createStatement();
   results = statement.executeQuery("SELECT * FROM agenda");
  }
  
  catch(SQLException sqlEx)
  {
   System.out.println(" Interogarea nu a putut fi executata.! ");
   sqlEx.printStackTrace();
   System.exit(1);
  }
  
  try
  {    
      int i=0;

      while (results.next())
     {  
      date[i]=new String();
			    date[i]="<td>"+results.getString(1)+"</td><td>" +
                                           results.getString(2)+"</td><td>" +
                                           results.getString(3)+"</td><td>" +
                                           results.getString(4)+"</td><td>" +
                                           results.getString(5)+"</td><td>" +
                                           results.getString(6)+"</td><td>" +
                                           results.getString(7)+"</td><td>" +
                                           results.getString(8)+"</td><td>" +
                                           results.getString(9)+"</td>" ;
                                i++;
     }
   n=i;
 } 
  catch(SQLException sqlEx)
  {
   System.out.println(" Eroare la primirea datelor! ");
   sqlEx.printStackTrace();
   System.exit(1);
  }

  try
  {
   link.close();
  }
  catch(SQLException sqlEx)
  {
   System.out.println(" Nu m-am putut deconecta! ");
   sqlEx.printStackTrace();
  }
                
 }
}

public class myServlet extends HttpServlet {

protected void processRequest(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException 
  {
        
    
    response.setContentType("text/html;charset=UTF-8");
        
        try (PrintWriter out = response.getWriter()) 
    {
      Date S=new Date();
      S.sir();
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Lista contactelor</title>");  
            out.println("<style>");
            out.println("#culoare { color: #1a8cff}");
            out.println("body { background-color: #cce5ff;}");
            out.println("a {text-decoration: none;}");
            out.println("</style>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1 id=\"culoare\">  Lista tuturor contactelor </h1>");  
            out.print("<table border='1'>");
            out.println("<tr><td>Nume<td>Prenume<td>TelefonMobil<td>TelefonFix<td>Email<td>Adresa<td>Oras<td>Judet<td>CodPostal");
            
            for(int i=0;i<S.n;i++)
             out.println("<tr>" + S.date[i] + "</tr>");
            
            out.println("</table>");
            out.println("</body>");
            out.println("</html>");
        }
   }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}