import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.*;
import javax.servlet.http.*;


class inform {
 static Connection link;
 static Statement statement;
 static ResultSet results; 
 
 
 public static String[] date = new String[50];
 static int n;
 
    
    public static void sir() {
        try
  {
   Class.forName("com.mysql.jdbc.Driver");
   link = DriverManager.getConnection("jdbc:mysql://localhost:3306/contacte", "root", "1234");
  }
                catch(ClassNotFoundException cnfe)
                {
                    System.out.println(" Driverul nu a putut fi incarcat! ");
                    System.exit(1);
                }
  catch(SQLException sqlEx)
  {
   System.out.println(" Conectarea la baza de date a esuat! ");
   System.exit(1);
  }

  try
  {
   statement = (Statement) link.createStatement();
   results = statement.executeQuery("SELECT * FROM agenda");
  }
  catch(SQLException sqlEx)
  {
   System.out.println(" Interogarea nu a putut fi executata.! ");
   sqlEx.printStackTrace();
   System.exit(1);
  }
  
   
  try
  {    
      
          int i=0;

   while (results.next())
   {  
        date[i]=new String();
			    date[i]="<td>"+results.getString(1)+"</td><td>" +
                                           results.getString(2)+"</td><td>" +
                                           results.getString(3)+"</td><td>" +
                                           results.getString(4)+"</td><td>" +
                                           results.getString(5)+"</td><td>" +
                                           results.getString(6)+"</td><td>" +
                                           results.getString(7)+"</td><td>" +
                                           results.getString(8)+"</td><td>" +
                                           results.getString(9)+"</td>" ;
                                i++; 
       
   }
  n=i;
  } 
  catch(SQLException sqlEx)
  {
   System.out.println(" Eroare la primirea datelor! ");
   sqlEx.printStackTrace();
   System.exit(1);
  }

  try
  {
   link.close();
  }
  catch(SQLException sqlEx)
  {
   System.out.println(" Nu m-am putut deconecta! ");
   sqlEx.printStackTrace();
  }
                
 }
}
public class sterge extends HttpServlet
{ 
 
 static Connection link;
 static Statement statement;
 static ResultSet results;
 
 
public void doGet(HttpServletRequest request,
HttpServletResponse response)
throws IOException,ServletException
{

   inform S=new inform();
     
   
response.setContentType("text/HTML");
PrintWriter out = response.getWriter();
out.println("<HTML>");
out.println("<HEAD>");
out.println("<TITLE>Simple Servlet</TITLE>");
out.println("</HEAD>");
out.println("<BODY>"); 

String nume = request.getParameter("Nume");
String prenume = request.getParameter("Prenume");
String adr = request.getParameter("Adresa");


try
      {
         
         Class.forName("com.mysql.jdbc.Driver");

         
         link = DriverManager.getConnection("jdbc:mysql://localhost:3306/contacte", "root", "1234");

      }
      catch(ClassNotFoundException cnfEx)
      {
         System.out.println ("* Nu am putut incarca driverul! *");
         System.exit(1);
      }
     
      catch(SQLException sqlEx)
      {
         System.out.println ("* Nu m-am putut conecta la baza de date! *");
         System.exit(1);
      }

        try
      { int result;
         statement = link.createStatement();
        String remove = "DELETE FROM contacte.agenda WHERE Nume = '" + nume + "' and Prenume = '" + prenume + "' and Adresa = '" + adr + "'" ;
         
         result = statement.executeUpdate(remove);
         
         if (result == 0)
            System.out.println("\nNu am putut sa sterg inregistrarea!");
  
       link.close(); 
      }
      catch(SQLException sqlEx)
      {
         System.out.println("* Eroare de conexiune sau interogare SQL! *");
         sqlEx.printStackTrace();
         System.exit(1);
      } 

S.sir();
 out.print("<table border='1'>");
 out.println("<tr><td>Nume<td>Prenume<td>TelefonMobil<td>TelefonFix<td>Email<td>Adresa<td>Oras<td>Judet<td>CodPostal");           
            for(int i=0;i<S.n;i++)
                out.println("<tr>" + S.date[i] + "</tr>");
            
            out.println("</table>"); 
out.println("</BODY>");
out.println("</HTML>");
out.flush();
}
}