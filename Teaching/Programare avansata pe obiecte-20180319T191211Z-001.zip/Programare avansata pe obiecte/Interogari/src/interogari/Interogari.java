/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interogari;
import java.sql.*;

/**
 *
 * @author Marina
 */
public class Interogari {
    
   static Connection link;
   static Statement statement;
   static ResultSet results;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         try
      {
         //Step 1...
         Class.forName("com.mysql.jdbc.Driver");

         //Step 2...
         link = DriverManager.getConnection("jdbc:mysql://localhost:3306/contacte", "root", "1234");

      }
      catch(ClassNotFoundException cnfEx)
      {
         System.out.println ("* Nu am putut incarca driverul! *");
         System.exit(1);
      }
      //For any of a number of reasons, it may not be
      //possible to establish a connection...
      catch(SQLException sqlEx)
      {
         System.out.println
                       ("* Nu m-am putut conecta la baza de date! *");
         System.exit(1);
      }

      try
      {
         //Step 3...
         statement = link.createStatement();

         System.out.println("\nContinutul intiial al tabelului:");
         //Steps 4 and 5...
         displayTable();

        //Start of step 6...
        /* String insert = "INSERT INTO contacte.agenda VALUES ('Manolescu','Stefan','0734256987', '0213467892','Manolescu.Stefan@yahoo.com', 'Teiului, nr.21',  'Timisoara', 'Timis', 383345)";
         int result = statement.executeUpdate(insert);
         if (result == 0)
            System.out.println("\nUnable to insert record!");

         String change = "UPDATE contacte.agenda SET Email = 'uiiuiuhuhui@yahoo.com' WHERE Nume = 'Petrescu'";
         result = statement.executeUpdate(change);
         if (result == 0)
            System.out.println("\nNu am putut actualiza inregistrarea!");*/

         String remove = "DELETE FROM contacte.agenda WHERE Nume = 'Badea'";
         
        int result = statement.executeUpdate(remove);
         
         if (result == 0)
            System.out.println("\nNu am putut sa sterg inregistrarea!");
  
         System.out.println("\nNoile date din tabel:");
         displayTable();
         //End of step 6.

         //Step 7...
         link.close(); 
      }
      catch(SQLException sqlEx)
      {
         System.out.println("* Eroare de conexiune sau interogare SQL! *");
         sqlEx.printStackTrace();
         System.exit(1);
      }
   } 

   public static void displayTable() throws SQLException
   {
      String select = "SELECT * FROM agenda";

      results = statement.executeQuery(select);

      System.out.println();

                   while (results.next())
                  {             System.out.println("Nume: " + results.getString(1));
				System.out.println("Prenume:  " + results.getString(2));
				System.out.println("Telefon Mobil: "+ results.getString(3));
                                System.out.println("Telefon Fix: " + results.getString(4));
                                System.out.println("Email: " + results.getString(5));
                                System.out.println("Adresa: " +results.getString(6));
                                System.out.println("Oras: " + results.getString(7));
                                System.out.println("Judet: " + results.getString(8));
                                System.out.println("Cod Postal: " + results.getString(9)); 
                                System.out.println(); 
                                System.out.println();
     
                  }
   }
}
    

