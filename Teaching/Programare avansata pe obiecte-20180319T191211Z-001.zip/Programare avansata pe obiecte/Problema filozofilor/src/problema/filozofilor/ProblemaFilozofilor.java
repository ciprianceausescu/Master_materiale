
package problema.filozofilor;
import java.net.*;
import java.util.*;

public class ProblemaFilozofilor 
{   

    
    public static void main(String[] args) 
    {    String host;
        Scanner input = new Scanner(System.in);
        InetAddress address;
        System.out.print("\n\nEnter host name: ");
        host = input.next();
 
        try
        {
            address = InetAddress.getByAddress;
            System.out.println("IP address: " + address.toString());
        }
        catch (UnknownHostException uhEx)
        {
            System.out.println("Could not find " + host);
        }
       
    }
    
}

