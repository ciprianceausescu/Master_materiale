
package bazadatemysql;
import java.sql.*;/*
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement; */


public class BazaDateMysql {
       static Connection link;
	static Statement statement;
	static ResultSet results;
   
    public static void main(String[] args) throws ClassNotFoundException
    
    {      /* try
		{
			Class.forName("com.mysql.jdbc.Driver");
			link = DriverManager.getConnection("jdbc:mysql://localhost:3306/contacte", "root", "1234");
		}
                catch(ClassNotFoundException cnfe)
                {
                    System.out.println("* Driverul nu a putut fi incarcat! *");
                    System.exit(1);
                }
		catch(SQLException sqlEx)
		{
			System.out.println("* Conectarea la baza de date a esuat! *");
			System.exit(1);
		}

		try
		{
			statement = (Statement) link.createStatement();
			results = statement.executeQuery("SELECT * FROM agenda");
		}
		catch(SQLException sqlEx)
		{
			System.out.println("* Interogarea nu a putut fi executata.! *");
			sqlEx.printStackTrace();
			System.exit(1);
		}

		try
		{
			System.out.println();

			while (results.next())
			{
				System.out.println("Nume: " + results.getString(1));
				System.out.println("Prenume:  " + results.getString(2));
				System.out.println("Telefon Mobil: "+ results.getString(3));
                                System.out.println("Telefon Fix: " + results.getString(4));
                                System.out.println("Email: " + results.getString(5));
                                System.out.println("Adresa: " +results.getString(6));
                                System.out.println("Oras: " + results.getString(7));
                                System.out.println("Judet: " + results.getString(8));
                                System.out.println("Cod Postal: " + results.getString(9)); 
                                System.out.println(); 
                                System.out.println();
                                
			}
		}
		catch(SQLException sqlEx)
		{
			System.out.println("* Eroare la primirea datelor! *");
			sqlEx.printStackTrace();
			System.exit(1);
		}

		try
		{
			link.close();
		}
		catch(SQLException sqlEx)
		{
			System.out.println("* Nu m-am putut deconecta! *");
			sqlEx.printStackTrace();
		} */
                String verif = "http://localhost:8084/WebApl/modifica?Nume=Pop&Prenume=Elena&Tmobil=0712743907&Tfix=0217439646&Email=Elena.Pop@gmail.com&Adresa=Ploilor%2C+nr.14&Oras=Bucuresti&Judet=Ilfov&Cod=264798";
                System.out.print(verif.length());
        
    }
    
    
}
