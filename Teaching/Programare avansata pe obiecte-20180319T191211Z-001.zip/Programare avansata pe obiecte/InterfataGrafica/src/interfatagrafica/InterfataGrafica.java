
package interfatagrafica;



public class InterfataGrafica {

     public static void main(String[] args) 
    {  NewJFrame f = new NewJFrame();
       f.show();
        
    }
    
}
