/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication30;
import java.sql.*;

/**
 *
 * @author Marina
 */
public class JavaApplication30 {
    
    static Connection link;
	static Statement statement;
	static ResultSet results;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try
		{
			Class.forName("com.mysql.jdbc.Driver");
			link = DriverManager.getConnection("jdbc:mysql://localhost:3306/datefinanciare", "root", "0709mar95");
		}
                catch(ClassNotFoundException cnfe)
                {
                    System.out.println("* Driverul nu a putut fi incarcat! *");
                    System.exit(1);
                }
		catch(SQLException sqlEx)
		{
			System.out.println("* Conectarea la baza de date a esuat! *");
			System.exit(1);
		}

		try
		{
			statement = (Statement) link.createStatement();
			results = statement.executeQuery("SELECT * FROM situatiefinanciara");
		}
		catch(SQLException sqlEx)
		{
			System.out.println("* Interogarea nu a putut fi executata.! *");
			sqlEx.printStackTrace();
			System.exit(1);
		}

		try
		{
			System.out.println();

			while (results.next())
			{
				System.out.println("Numar cont. " + results.getInt(1));
				System.out.println("Titularul contului:  " 
                                                                 + results.getString(3)
								 + " "+ results.getString(2));
				System.out.printf("Soldul: ",	results.getString(4));
			}
		}
		catch(SQLException sqlEx)
		{
			System.out.println("* Eroare la primirea datelor! *");
			sqlEx.printStackTrace();
			System.exit(1);
		}

		try
		{
			link.close();
		}
		catch(SQLException sqlEx)
		{
			System.out.println("* Nu m-am putut deconecta! *");
			sqlEx.printStackTrace();
		}
    }
    
}
