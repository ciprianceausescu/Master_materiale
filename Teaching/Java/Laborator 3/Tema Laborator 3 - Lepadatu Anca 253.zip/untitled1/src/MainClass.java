import java.util.Scanner;

public class MainClass {
    public static void main(String[] args) {
        Complex a1 = new Complex (1, 1);
        Complex a2 = new Complex (1, 1);
        Complex suma = new Complex ();
        Complex produs = new Complex ();
        Complex putere = new Complex ();
        Complex a3 = new Complex (4, 3);
        System.out.println(a1);
        System.out.println(a2);
        System.out.println(suma);
        suma = a2.adunare(a1);
        produs = a2.inmultire(a1);

        System.out.println("a1 + a2 = " + suma);
        System.out.println("a1 * a2 = " + produs);


        System.out.print("Se cere o putere la care sa fie ridicat a1: ");
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        putere = a1.putere(n);

        System.out.println("a1^" + n + " = " + putere);

        System.out.println("a1 == a3: " + (a1 == a3));
        System.out.println("a1 equals a3: " + (a1.equals(a3)));
    }
}