public class Complex {
    int re, im;
    Complex() {
        re = 0;
        im = 0;
    }
    Complex (int re, int im) {
        this.re = re;
        this.im = im;
    }

    Complex adunare (Complex x) {
        Complex c = new Complex();
        c.re = this.re + x.re;
        c.im = this.im + x.im;
        return c;
    }

    Complex inmultire (Complex x) {
        Complex c = new Complex();
        c.re = this.re * x.re - this.im * x.im;
        c.im = this.re * x.im + this.im * x.re;
        return c;
    }

    Complex putere (int n) {
        Complex c = new Complex(this.re, this.im);
        for (int i = 1; i < n; i++) {
            c = c.inmultire(this);
        }
        return c;
    }

    @Override
    public String toString() {
        return String.valueOf(re) + " + " + String.valueOf(im) + "i";
    }
    @Override
    public boolean equals(Object x) {
        if (re == ((Complex)x).re && im == ((Complex)x).im)
            return true;
        else
            return false;
    }
}