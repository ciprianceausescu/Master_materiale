

public class MainClass {
    public static void main(String[] args) {
        Stiva s = new Stiva(10);
        Stiva s2 = new Stiva();

        s.push(6);
        s.push(7);
        s.push(5);
        s.push(3);

        System.out.println("Element popped: " + s.pop());

        for (int i = 0; i < s.vf; i++) {
            System.out.print(s.v[i] + " ");
        }

        System.out.println("s is empty: " + s.isEmpty());
        System.out.println("s2 is empty: " + s2.isEmpty());

        s2.push(2);
        s2.pop();
        s2.pop();
        System.out.println("s2 is empty: " + s2.isEmpty());


    }
}

