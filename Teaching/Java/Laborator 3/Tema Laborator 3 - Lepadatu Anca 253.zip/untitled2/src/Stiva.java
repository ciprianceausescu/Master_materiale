public class Stiva {
    int v[];
    int vf;

    Stiva () {
        v = new int[100];
        vf = 0;
    }

    Stiva (int n) {
        v = new int[n];
        vf = 0;
    }

    void push (int x) {
        v[vf] = x;
        vf++;
    }

    int pop () {
        if(this.isEmpty ()) {
            System.out.println("Nu mai pot fi eliminate elemente.");
            return -1;

        }

        int x = v[vf-1];
        vf--;

        return x;

    }

    boolean isEmpty() {
        if (vf == 0)
            return true;
        else
            return false;
    }
}

