/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3;



public class complex {
    double x,y;
    complex()
    {
        x = 0;
        y = 0;
    }
    complex(double a, double b)
    {
        x=a;
        y=b;
    }
    complex adunare( complex b)
    {
        complex n = new complex(this.x+b.x,this.y+b.y);
        return n;
    }
    complex inmultire( complex b)
    {
        complex n = new complex(this.x*b.x - this.y*b.y,this.x*b.y + this.y*b.x);
        return n;
    }
    public double abs()
    {
        return StrictMath.sqrt(StrictMath.pow(this.x, 2) + StrictMath.pow(this.y, 2));
    }
    public double arg()
    {
        double theta = StrictMath.atan2(this.y,this.x);

        return theta;
    }
    public complex pow(complex b)
    {
        double c = b.x;
        double d = b.y;

        // get polar of base
        double r = this.abs();
        double theta = this.arg();

        complex f1 = new complex((StrictMath.pow(r, c)*StrictMath.pow(StrictMath.E, -d*theta)),0);
        complex f2 = new complex(StrictMath.cos(d*StrictMath.log(r)+c*theta),StrictMath.sin(d*StrictMath.log(r)+c*theta));

        return f1.inmultire(f2);

    }
    @Override
    public String toString()
    {
        return x + "+i*" + y;
    }
    public boolean equals(complex b)
    {
        return this.x == b.x && this.y == b.y;
    }
}