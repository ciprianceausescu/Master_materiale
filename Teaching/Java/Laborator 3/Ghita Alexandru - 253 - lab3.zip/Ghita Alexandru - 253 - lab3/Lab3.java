/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3;


public class Lab3 {

    public static void main(String args[])
    {
        int choice = 2;
        switch(choice) {
            case 0:
            complex a = new complex(1, 1);
            complex b = new complex(1, 1);
            System.out.println(a);
            System.out.println(b);
            System.out.println(a.adunare(b));
            System.out.println(a.inmultire(b));
            System.out.println(a.pow(b));
            System.out.println(a.equals(b));
            b = a;
            System.out.println(a.equals(b));
            break;
            case 1:
                stiva s = new stiva(10);
                s.push(5);
                s.push(6);
                System.out.println(s);
                System.out.println(s.pop());
                System.out.println(s);
                System.out.println(s.isEmpty());
                System.out.println(s.pop());
                System.out.println(s.isEmpty());
                break;
            case 2:
                triunghi t = new triunghi(5);
                int nr = 1;
                for(int i=0;i<5;i++)
                    for(int j=0;j<=i;j++)
                        t.add(i,j,nr++);
                System.out.println(t);
                break;
        }
    }
}