/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3;


public class triunghi {
    int[][] v;
    int n;
    triunghi()
    {
        n = 10;
        v = new int[n][];
        for(int i=0; i < n; i++)
            v[i] = new int[i+1];

        for(int i=0;i<n;i++)
            for(int j=0;j<=i;j++)
                v[i][j] = 0;
    }
    triunghi(int b)
    {
        n = b;
        v = new int[n][];
        for(int i=0; i < n; i++)
            v[i] = new int[i+1];

        for(int i=0;i<n;i++)
            for(int j=0;j<=i;j++)
                v[i][j] = 0;
    }
    public void add(int i,int j,int b)
    {
        v[i][j] = b;
    }
    @Override
    public String toString()
    {
        for(int i=0;i<n;i++, System.out.println(""))
            for(int j=0;j<=i;j++)
                System.out.print(v[i][j] + " ");
        return "";
    }
}
