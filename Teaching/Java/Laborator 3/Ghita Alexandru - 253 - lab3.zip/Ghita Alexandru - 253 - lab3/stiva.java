/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3;


public class stiva {
    int[] v;
    int n;
    stiva()
    {
        n = -1;
        v = new int[100];
    }
    stiva(int n)
    {
        this.n = -1;
        v = new int[n];
    }
    public void push(int b)
    {
        if(n < v.length)
            v[++n] = b;
    }
    public int pop()
    {
        if(n > -1)
            return v[n--];
        else
            return 0;
    }
    public boolean isEmpty()
    {
        return n == -1;
    }
    @Override
    public String toString()
    {
        for(int i=0;i<=n;i++)
            System.out.print(v[i] + " ");
        return "";
    }
}
