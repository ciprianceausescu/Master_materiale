package app.service;

import app.login.*;
import app.util.*;
import spark.*;
import java.util.*;
import static app.Application.bookDao;
import static app.util.JsonUtil.*;
import static app.util.RequestUtil.*;

public class ServiceController {

    // todo:: make crud for services so admin can add his own
    // never mind, this thing is EXACTLY as the other cruds , i'm bored
}
