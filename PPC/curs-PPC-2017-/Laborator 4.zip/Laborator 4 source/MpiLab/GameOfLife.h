#pragma once

#include <stdio.h>
#include <time.h>

struct RectToCompute
{
	int rowStart;
	int rowEnd;
	int colStart;
	int colEnd;

	RectToCompute()
	{
		rowStart = rowEnd = 0;
		colStart = colEnd = 0;
	}
};

class GameOfLife
{
public:
	GameOfLife(const int numRows, const int numColumns)
	{
		mNumRows = numRows;
		mNumCols = numColumns;

		mTable1 = new char*[mNumRows];
		mTable2 = new char*[mNumRows];
		
		for (int i = 0; i < mNumRows; i++)
		{
			mTable1[i] = new char[mNumCols];
			mTable2[i] = new char[mNumCols];

			memset(&mTable1[i][0], 0, sizeof(char) * mNumCols);
			memset(&mTable2[i][0], 0, sizeof(char) * mNumCols);
		}
	}

	virtual ~GameOfLife()
	{
		for (int i = 0; i < mNumRows; i++)
		{
			delete [] mTable1[i];
			delete [] mTable2[i];
		}

		delete [] mTable1;
		delete [] mTable2;
	}

	void Initialize(const float lifeProbability, const RectToCompute& rect)
	{
		mFrontTable = mTable1;
		mBackTable  = mTable2;

		// Comment this / or set seed by hand if you want (more) determinism 
		srand(time(NULL) + (int)mTable1 + (int)mTable2);
		for (int i = rect.rowStart; i <= rect.rowEnd; i++)
		{
			for (int j = rect.colStart; j <= rect.colEnd; j++)
			{
				const float randNum = ((float)rand() / RAND_MAX);
				mFrontTable[i][j] = randNum < lifeProbability ? true : false;
			}
		}
	}

	void Update(const RectToCompute& rect)
	{
		std::swap(mFrontTable, mBackTable);

		// (y,x) - clockwise order
		const int numNeighb = 8;
		const int dirs[numNeighb][2] = { { -1, 0 }, { -1, 1 }, { 0, 1 }, { 1, 1 }, { 1, 0 },
		{ 1, -1 }, { 0, -1 }, { -1, -1 } };

		for (int i = rect.rowStart; i <= rect.rowEnd; i++)
		{
			for (int j = rect.colStart; j <= rect.colEnd; j++)
			{
				int numAliveNeighb = 0;
				for (int neighDir = 0; neighDir < numNeighb; neighDir++)
				{
					const int r = i + dirs[neighDir][0];
					const int c = j + dirs[neighDir][1];

					if (!IsValid(r, c))
						continue;

					numAliveNeighb += mBackTable[r][c];
				}

				mFrontTable[i][j] = mBackTable[i][j];

				if (numAliveNeighb >= 3)
					mFrontTable[i][j] = true;
				else if (numAliveNeighb < 2)
					mFrontTable[i][j] = false;
			}
		}
	}

	void DebugPrint(const RectToCompute& rect)
	{
		printf("\n\n-------------------------");
		for (int i = rect.rowStart; i <= rect.rowEnd; i++)
		{
			printf("\n");
			for (int j = rect.colStart; j <= rect.colEnd; j++)
			{
				printf("%d ", mFrontTable[i][j]);
			}
		}
	}

	// We need two tables and one pointer. We'll switch between them (double buffering tehnique)
	char** mTable1;
	char** mTable2;

	int mNumRows;
	int mNumCols;

	char **mFrontTable;
	char **mBackTable;

private:
	bool IsValid(const int row, const int col)
	{
		return (0 <= row && row < mNumRows && 0 <= col && col < mNumCols);
	}
};

